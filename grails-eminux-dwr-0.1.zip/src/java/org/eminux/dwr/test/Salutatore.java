/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package org.eminux.dwr.test;

/**
 *
 * @author frem0
 */
public class Salutatore {
    
    public Salutatore(){
        
    }
    
    public String saluta(String nome){
        return "Ciao "+nome;
    }
    
}
